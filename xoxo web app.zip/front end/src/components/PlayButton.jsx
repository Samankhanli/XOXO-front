import { useEffect, useState } from "react";

function PlayButton({
  turn,
  setSelecter,
  setTurn,
  isdone,
  replay,
  resetReplay,
}) {
  let [clicked, setClicked] = useState(isdone);
  let [bcolor, setBcolor] = useState("");
  let [text, setText] = useState("");

  useEffect(
    (event) => {
      setClicked(isdone);
    },
    [isdone]
  );
  useEffect(() => {
    if (replay == true) {
      setClicked(false);
      setText("");
    }
  }, [replay]);

  return (
    <div
      style={{
        width: "30%",
        backgroundColor: "black",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: bcolor,
        fontSize: "50px",
        marginTop: "20px",
        position: "relative",
        aspectRatio: "1/1",
        borderRadius: "10px",
      }}
      onClick={
        clicked
          ? null
          : () => {
              setBcolor(turn % 2 == 1 ? "blue" : "red");
              setText(turn % 2 == 1 ? "X" : "O");
              setSelecter(turn % 2 == 1 ? 1 : 2);
              setClicked(true);
              setTurn();
              resetReplay();
            }
      }
    >
      {text ? <p>{text}</p> : null}
    </div>
  );
}
export default PlayButton;
