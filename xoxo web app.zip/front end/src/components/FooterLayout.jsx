import { Outlet } from "react-router-dom";
function FooterLayout() {
  return (
    <div style={{ height: "80%" }}>
      <div style={{ minHeight: "85%" }}>
        <Outlet />
      </div>
      <p
        style={{
          textAlign: "center",
          color: "rgba(250, 131, 5, 1)",
          fontSize: "30px",
        }}
      >
        Proved by Saman 2024
      </p>
    </div>
  );
}
export default FooterLayout;
