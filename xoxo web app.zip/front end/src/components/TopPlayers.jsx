import useTopTenUsers from "../hooks/useTopTenUsers";

function TopPlayers() {
  let { data } = useTopTenUsers();


  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        flexDirection: "column",
        width: "100%",
        color: "white",
      }}
    >
      <h1>SCORE TABLE(Top 10)</h1>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          width: "100%",
          flexDirection: "column",
        }}
      >
        <div
            style={{
              display: "flex",
              width: "70%",
              justifyContent: "space-between",
              fontSize: "30px"
            }}
        ><p>ROW</p>
            <p>NAME</p>
            <p>SCORE</p>
        </div>
        {data?.map((item, index) => (
          <div
            style={{
              display: "flex",
              width: "70%",
              justifyContent: "space-between",
            }}
            key={index}
          >
            <p>{index+1}</p>
            <p>{item.name}</p>
            <p>{item.score}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
export default TopPlayers;
